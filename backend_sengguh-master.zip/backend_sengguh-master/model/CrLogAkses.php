<?php

class CrLogAkses extends A
{

}