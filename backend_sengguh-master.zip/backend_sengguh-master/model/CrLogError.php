<?php

class CrLogError extends A
{

}
