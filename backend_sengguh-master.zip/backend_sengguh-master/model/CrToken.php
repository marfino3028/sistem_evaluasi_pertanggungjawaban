<?php

class CrToken extends A
{

}