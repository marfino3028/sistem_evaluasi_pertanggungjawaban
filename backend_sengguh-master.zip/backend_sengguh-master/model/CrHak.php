<?php

class CrHak extends A
{
            
}