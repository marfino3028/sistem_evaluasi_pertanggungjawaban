<?php

class CrApp extends A
{

}