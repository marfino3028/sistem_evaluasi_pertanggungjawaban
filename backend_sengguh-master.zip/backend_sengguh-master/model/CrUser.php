<?php

class CrUser extends A
{

}