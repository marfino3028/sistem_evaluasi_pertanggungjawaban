<?php

class CrResource extends A
{
            
}