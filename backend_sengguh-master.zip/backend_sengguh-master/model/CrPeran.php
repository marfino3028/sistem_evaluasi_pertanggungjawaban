<?php

class CrPeran extends A
{

}