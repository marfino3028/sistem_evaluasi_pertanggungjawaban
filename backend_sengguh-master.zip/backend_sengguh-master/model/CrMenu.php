<?php

class CrMenu extends A
{

}