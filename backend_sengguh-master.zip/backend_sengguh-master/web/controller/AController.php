<?php

use Phalcon\Mvc\Controller;

class AController extends Controller
{
    public function initialize()
    {
    }
}