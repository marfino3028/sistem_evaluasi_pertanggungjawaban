<?php
class Pesan {
    public $kode;
    public $deskripsi;
}
