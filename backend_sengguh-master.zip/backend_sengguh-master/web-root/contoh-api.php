<pre>
login : auth/index
{
    "username" : "xxx",
    "password" : "xxx"
}

cek info login : auth/cek
{
    "token" : "xxx"
}

logout : auth/logout
{
    "token" : "xxx"
}

test : test/index
{
    "token" : "xxx"
}
</pre>